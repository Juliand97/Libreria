<html>
<head>
<title>Menu de proyecto</title>
<meta charset= "uft-8">
</head>

<body>
<p>Menu de opciones</p>
<p><a href="registrareditorial.php">Registrar Editorial</p>
<p><a href="consultareditorial1.php">Consultar Editorial</p>
<p><a href="actualizareditorial.php">Actualizar Editorial</p>
<p><a href="borrar.html">Borra Editorial</p>



</body>
</html>