<html>
<head>
</head>

<body>
<p>&nbsp;</p>
<form name="form1" method="post" action="actualizareditorial1.php?tipo=registrar">
  <p>Actualizar Editorial  </p>
  <table width="200" border="1">
    <tr>
      <td>Escriba el codigo postal a consultar:</td>
      <td><input type="text" name="codigo_postal" id="codigo_postal"></td>
    </tr>
    <tr>
      <td><input type="submit" name="Guardar" id="Guardar" value="Enviar"></td>
      <td>&nbsp;</td>
    </tr>
  </table>

</form>
<form action="consultareditorial1.php" method="post">
<input type="submit" value="Hacer consulta">
</form>
<p><a href="menu.php">Volver al menu principal</a></p>
</body>
</html>
